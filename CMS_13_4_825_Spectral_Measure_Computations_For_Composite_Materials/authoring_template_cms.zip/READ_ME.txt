To authors:

First, try to use the Latex2e class file "ip-journal.cls". Most 
authors use this without difficulty.

However, if you have trouble with "ip-journal.cls", use instead 
the older Latex class file "CMSLATEX.cls".

Please note that "ip-journal.cls" does NOT depend on any of the 
other configuration files here: Those files are for "CMSLATEX.cls".
